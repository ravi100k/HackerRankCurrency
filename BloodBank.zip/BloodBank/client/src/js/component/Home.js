var React=require("React");

 var Home=React.createClass({

   render: function() {
     return (
     	<div>
     	
     	</div>
     )
   }
 });
 module.exports = Home;
