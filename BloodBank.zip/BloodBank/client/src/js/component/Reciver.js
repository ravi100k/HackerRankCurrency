var React=require("React");
var Reciver=React.createClass({

getInitialState:function()
{	
    return {Name:'',BloodGroup:'',Hospital:'',UnitsofBlood:''};
},
handleNameChange: function(e) {
    this.setState({Name: e.target.value});
  },
handleBloodGroupChange: function(e) {
    this.setState({BloodGroup: e.target.value});
  },
  handleHospitalChange: function (e) {
  	this.setState({Hospital:e.target.value});
  },
  handleUnitsofBloodChange: function(e){
  	this.setState({UnitsofBlood:e.target.vlaue});
  },
sendDataToParent: function()
{
	var jsonData = {
    Name:this.state.Name,
    BloodGroup:this.state.BloodGroup,
    Hospital:this.state.Hospital,
    UnitsofBlood:this.state.UnitsofBlood
    };
    alert("Created successfully");
    $.ajax({
      url: 'http://localhost:8085/bloodbank/add',
      type:'POST',
      dataType: 'json',
      data:jsonData,
      cache: false,
      success: function(data1) {
        //console.log(data1);
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(this.state.url, status, err.toString());
      }.bind(this)
    });
    this.setState({Name:'',BloodGroup:'',Hospital:'',UnitsofBlood:''});
},

reset:function(){
     this.setState({Name:'',BloodGroup:'',Hospital:'',UnitsofBlood:''});
     alert("Reset successfully");
   },

render: function(){
   return (
     <div>
     <h2 id='heading'>Reciver Of Blood</h2>
      <div id="form">
      <ul>
      <p>
      <li><em>Name:</em>{" "}<input type="text" required placeholder='Name of Patient' value={this.state.Name} onChange={this.handleNameChange}/>
      </li>
      </p>
      <p>
      <li><em>Blood Group:</em>{" "}<input type="text" placeholder='Blood Group' required id="bloodgroup" value={this.state.BloodGroup} onChange={this.handleBloodGroupChange}/>
      </li></p>
      <p>
      <li><em>Hospital Name:</em>{" "}<input type="text" placeholder='Name Of Hospital' required id="nameofhospital"value={this.state.Hospital} onChange={this.handleHospitalChange}/>
      </li></p>
      <p>
      <li><em>Amount Of Blood Needed:</em>{" "}<input type="number" min="1" max="50" placeholder='Blood Needed in Units' id="bloodunit" value ={this.state.UnitsofBlood} onChange={this.handleUnitsofBloodChange}/>
      </li></p>
      
      <button id="submit" type="button" className="btn btn-primary" onClick={this.sendDataToParent}>Submit</button>
      {"  "}
      <button id="submit" type="button" className="btn btn-primary" onClick={this.reset}>Reset</button>
     
      </ul>
     </div>
     </div>
   )
 }
});
module.exports=Reciver;