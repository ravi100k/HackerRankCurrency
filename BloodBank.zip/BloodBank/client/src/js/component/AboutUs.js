var React=require("React");

 var AboutUs=React.createClass({

   render: function() {
     return (
       <div>
       
       </div>
     )
   }
 });
 module.exports = AboutUs;
